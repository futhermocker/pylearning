# -*- coding:utf-8 -*

import numpy as np
import cv2
import os
import os.path

# lsdidir = '/Volumes/Chickenwinwin/__data/taotaosou.com/result_data/Bags/test_img/'    #LSD结果图像存储地址
# resultdir = '/Volumes/Chickenwinwin/__data/taotaosou.com/result_data/Bags/result/'		#聚类中心转换成图片的存储地址
# cluster_n = 100

lsdidir = '/Users/chickenchen/Desktop/__data/taotaosou.com/product_pic_n/result_data/Bags/test_img/'    #LSD结果图像存储地址
resultdir = '/Users/chickenchen/Desktop/__data/taotaosou.com/product_pic_n/result_data/Bags/result/'		#聚类中心转换成图片的存储地址
resultimg = '/Users/chickenchen/Desktop/__data/taotaosou.com/product_pic_n/result_data/Bags/result_img/' 		#最靠近聚类中心的图像的存储地址
cluster_n = 100

points = []
newpoints = []
counter = 0
psum = np.zeros(10000)
for filename in os.listdir(lsdidir):
	if os.path.isfile(os.path.join(lsdidir,filename)):
		filedir = os.path.join(lsdidir,filename)
		img = cv2.imread(filedir,0)
		if img == None:
			print "AOh!"
			continue
		newimg = img[2:202, 2:202]
		newimg = cv2.resize(newimg, (100,100), interpolation = cv2.INTER_CUBIC)
		points.append(newimg.ravel())

		meanmatrix = np.ones(10000) * newimg.mean()
		stdevmatrix = np.sqrt(np.ones(10000) * (newimg.var() + 10))
		newimg = (newimg.ravel() - meanmatrix) / stdevmatrix
		newpoints.append(newimg)
		counter += 1
print 'load finally!'

term_crit = (cv2.TERM_CRITERIA_EPS, 20, 0.1)
pointk = np.float32( np.vstack(newpoints) )
ret, labels, centers = cv2.kmeans(pointk, cluster_n, term_crit, 3, 0)
print 'finish kmeans!'

i = 0  
for tempimg in centers:
	np.savetxt(resultdir + str(i) + '.txt', tempimg)

	j = 0
	label = 0
	dist = np.sqrt(np.sum((newpoints[0] - tempimg) ** 2))
	for point in newpoints:
		d = np.sqrt(np.sum((point - tempimg) ** 2))
		if d < dist:
			dist = d
			label = j
		j += 1

	result = points[label]
	result.shape = (100, 100)
	cv2.imwrite(resultimg + str(i) + '.pgm', result)
	i += 1
print 'finish write'

### cv2.imshow('rerrr',img)
### cv2.waitKey(0) & 0xFF	#64位操作系统需要加上 '& 0xFF' 
### cv2.destroyAllWindows()