# -*- coding:utf-8 -*

import cv2
import numpy as np
import os

img = cv2.imread('shit3.jpg',0)
# 检查读入的图片是否正确
if img == None:
	print "shit!"
	os._exit(0)
img = cv2.resize(img, (256,256), interpolation = cv2.INTER_CUBIC)
cv2.imwrite('shit3.pgm', img)
#dst = cv2.imread('shit3.pgm',0)
#cv2.imshow('rerrr',dst)

# 通过调用外部程序 LSD 1.6 ，对jpg格式图片进行LSD操作
os.system('./lsd_1.6/lsd -R helo.pgm shit3.pgm helo.lsd.txt')

#cv2.waitKey(0) & 0xFF	#64位操作系统需要加上 '& 0xFF' 
#cv2.destroyAllWindows()
