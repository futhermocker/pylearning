# -*- coding:utf-8 -*

import numpy as np
import cv2
import os
import os.path

resultdir = '/Volumes/Chickenwinwin/__data/taotaosou.com/result_data/Bags/result/'		#聚类中心转换成图片的存储地址

img = cv2.imread(resultdir + '2.pgm', 0)
# eignvalues, eignvectors = np.linalg.eig(img)
# ret, eignvalues, eignvectors = cv2.eigen(img, 0)
a = np.mat(eignvectors)
print img
print eignvectors * eignvalues * a.I
for b in eignvectors * eignvalues * a.I:
	print b
cv2.imshow('rerrr',img)
cv2.waitKey(0) & 0xFF	#64位操作系统需要加上 '& 0xFF' 
cv2.destroyAllWindows()