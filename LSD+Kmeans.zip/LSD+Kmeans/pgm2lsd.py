# -*- coding:utf-8 -*

import cv2
import numpy as np
import os
import os.path

# def resizeimg:
# 	img = cv2.imread('', 0)

# def jpg2pgm:
# 	cv2.

# def pgm2lsd: 
# 	os.system('./lsd_1.6/lsd -P helo.eps helo.jpg helo.lsd.txt')

# rootdir = '/Volumes/Chickenwinwin/__data/taotaosou.com/product_pic_n/Bags'    #指明遍历所有文件的文件夹
# graydir = '/Volumes/Chickenwinwin/__data/taotaosou.com/result_data/Bags/gray_img/'    #灰度图像存储地址
# lsdidir = '/Volumes/Chickenwinwin/__data/taotaosou.com/result_data/Bags/lsd_img/'    #LSD结果图像存储地址
# lsdtdir = '/Volumes/Chickenwinwin/__data/taotaosou.com/result_data/Bags/lsd_txt/'    #LSD结果数据存储地址

rootdir = '/Users/chickenchen/Desktop/__data/taotaosou.com/product_pic_n/Bags'    #指明遍历所有文件的文件夹
graydir = '/Users/chickenchen/Desktop/__data/taotaosou.com/product_pic_n/result_data/Bags/gray_img/'    #灰度图像存储地址
lsdidir = '/Users/chickenchen/Desktop/__data/taotaosou.com/product_pic_n/result_data/Bags/lsd_img/'    #LSD结果图像存储地址
lsdtdir = '/Users/chickenchen/Desktop/__data/taotaosou.com/product_pic_n/result_data/Bags/lsd_txt/'    #LSD结果数据存储地址

for filename in os.listdir(rootdir):
	if os.path.isfile(os.path.join(rootdir,filename)):
		filedir = os.path.join(rootdir,filename)
		# print filedir
		img = cv2.imread(filedir, 0)
		#  检查读入的图片是否正确
		if img == None:
			print "AOh!"
			continue
		img = cv2.resize(img, (256,256), interpolation = cv2.INTER_CUBIC)
		cv2.imwrite(graydir + filename + '.pgm', img)
		### dst = cv2.imread('shit3.pgm',0)
		### cv2.imshow('rerrr',dst)

		#  通过调用外部程序 LSD 1.6 ，对jpg格式图片进行LSD操作
		os.system('./lsd_1.6/lsd -R ' + lsdidir + filename + '.pgm' + ' ' + graydir + filename + '.pgm'  + ' ' + lsdtdir + filename + '.lsd.txt')
		### cv2.waitKey(0) & 0xFF	#64位操作系统需要加上 '& 0xFF' 
		### cv2.destroyAllWindows()
